from rest_framework import status
from django.http import HttpResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
from myapp.models import Regester,Login,Database,Map
from myapp.serializers import SnippetSerializer,Blockdata,Mapinfo
from rest_framework.decorators import parser_classes
from rest_framework.parsers import MultiPartParser, FormParser
from uuid import getnode as get_mac
from ipware.ip import get_ip



@api_view(['GET', 'POST'])
@parser_classes((FormParser, MultiPartParser))
def Regesterview(request):
	if request.method == 'GET':
		myapp = Regester.objects.all()
		serializer = SnippetSerializer(myapp, many=True)
		return Response(serializer.data)

	elif request.method == 'POST':
		print request.data
		print "++++++++++++++++++"
		serializer = SnippetSerializer(data=request.data)
		#print serializer
		if serializer.is_valid():
			serializer.save()
			return Response(serializer.data, status=status.HTTP_201_CREATED)
		return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'POST'])
@parser_classes((FormParser, MultiPartParser))
def Block(request):
	if request.method == 'GET':
		my = Database.objects.all()
		ser = Blockdata(my, many=True)
		return Response(ser.data)

	elif request.method == 'POST':
		block_ip_int = request.data['block_ip_int']

		block_number = request.data['block_number']

		block_name = request.data['block_name']
		hello = Database(block_ip_int=block_ip_int,block_number=block_number,block_name=block_name)
		hello.save()
		return Response(status=status.HTTP_201_CREATED)
		return Response( status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'POST'])
@parser_classes((FormParser, MultiPartParser))
def Mapview(request):
	if request.method == 'GET':
		myapp = Map.objects.all()
		serializer = Mapinfo(myapp, many=True)
		return Response(serializer.data)

	elif request.method == 'POST':

		number1 = request.data['number1']
		out = request.data['out']
		name1 = request.data['name1']
		dest = request.data['dest']
		map_pic = request.data['map_pic']
		hi = Map(number1=number1,out=out,name1=name1,dest=dest,map_pic=map_pic)
		hi.save()
		return Response( status=status.HTTP_201_CREATED)
		return Response( status=status.HTTP_400_BAD_REQUEST)



@api_view(['POST'])
def Loginview(request):
	phone_number = request.data['phone_number']
	password = request.data['password']
	sai = Regester.objects.get(phone_number=phone_number,password=password)
	ip = get_ip(request)
	ip_split = ip.split('.')
	get_int =(ip_split[1])
	print ip_split
	print get_int
	my = Login(ip=ip,password=password,phone_number=phone_number,ip_int=get_int)
	my.save()
	file = Database.objects.get(block_ip_int=get_int)
	print ip
	location = file.block_number
	print location
	return Response( ("welocome you are in",location,"block"),status=status.HTTP_201_CREATED)
	return Response( status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def Find(request):
	print "$$$$$$$$$$$$$$$$$$$$"
	ip = get_ip(request)
	ip_split = ip.split('.')
	get_int =(ip_split[1])
	print get_int
	file = Database.objects.get(block_ip_int=get_int)
	my_location = file.block_number
	print my_location
	loca = request.data['loca']
	print loca
	direction = Map.objects.get(number1=my_location,out=loca)
	return HttpResponse(( direction.map_pic))
	return Response( status=status.HTTP_400_BAD_REQUEST)

	#my_location = Database.objects.get('block_ip_int')
	
@api_view(['POST'])
def Findfriend(request):
	print "$$$$$$$$$$$$$$$$$$$$"
	ip = get_ip(request)
	ip_split = ip.split('.')
	get_int =(ip_split[1])
	print get_int
	file = Database.objects.get(block_ip_int=get_int)
	my_location = file.block_number
	print my_location
	frinum = request.data['friendnum']
	print frinum
	direction = Login.objects.get(phone_number=frinum)
	friendip = direction.ip_int
	print friendip
	friendloc = Database.objects.get(block_ip_int=friendip)
	block = friendloc.block_number
	directionfri = Map.objects.get(number1=my_location,out=block)
	sai = directionfri.map_pic
	print sai
	return HttpResponse(( directionfri.map_pic))
	
	return Response( status=status.HTTP_400_BAD_REQUEST)
	





	
	
	
		
		
	

	

   


#@api_view(['POST'])
#def Chech(request):
	#file_id = request.data['number']
	#file = Document.objects.get(number=file_id)
	#return HttpResponse(( file.block_number))
	#return Response(file.block_number)
	
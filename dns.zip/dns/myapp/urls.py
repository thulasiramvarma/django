from django.conf.urls import patterns, include, url
from myapp.views import Regesterview,Loginview,Mapview,Block,Find,Findfriend

urlpatterns = patterns('myapp.views',
   
    url(r'^regester/$', Regesterview, name="upload_pic"),
    url(r'^loginview/$',Loginview, name="loginview"),
    url(r'^block/$', Block, name="block"),
    url(r'^map/$', Mapview, name="map"),
    url(r'^find/$', Find, name="find"),
    url(r'^findfriend/$', Findfriend, name="findfriend"),
   
)


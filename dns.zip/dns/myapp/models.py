# # -*- coding: utf-8 -*-

from django.db import models




class Regester(models.Model):
	
	name = models.CharField(max_length=100)
	password = models.CharField(max_length=20)
	phone_number = models.CharField(max_length=20)
	time = models.DateTimeField(auto_now_add=True)
	
	

class Login(models.Model):

	password = models.CharField(max_length=20)
	phone_number = models.CharField(max_length=20)
	ip = models.CharField(max_length=100)
	ip_int = models.CharField(max_length=100)
	time = models.DateTimeField(auto_now_add=True)

class Database(models.Model):

	block_ip_int = models.CharField(max_length=20)
	block_number = models.CharField(max_length=20)
	block_name = models.CharField(max_length=200)
	time = models.DateTimeField(auto_now_add=True)

class Map(models.Model):

	number1 = models.CharField(max_length=20)
	out = models.CharField(max_length=20)
	name1 = models.CharField(max_length=200)
	dest = models.CharField(max_length=200)
	map_pic = models.FileField(upload_to='documents/%Y/%m/%d')
	time = models.DateTimeField(auto_now_add=True)
	
from rest_framework import serializers
from myapp.models import Regester,Login,Database,Map
#from django.contrib.auth import authenticate, get_user_model

class SnippetSerializer(serializers.ModelSerializer):
	class Meta:
		model =  Regester
		fields = (
			"name",
			
			
			"password",
			
			"phone_number",
			
			)
class Blockdata(serializers.ModelSerializer):
	class Meta:
		model =  Database
		fields = (
			"block_ip_int",
			
			
			"block_number",
			
			"block_name",
			
			)
class Mapinfo(serializers.ModelSerializer):
	class Meta:
		model =  Map
		fields = (
			"number1",
			"out", 
			"name1", 
			"dest", 
			"map_pic", 
			
			)


	def create(self, validated_data):
	    return  Regester.objects.create(**validated_data)
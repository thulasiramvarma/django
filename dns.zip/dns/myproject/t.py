import os
PROJECT_ROOT = os.path.realpath(os.path.dirname(__file__))

print 'PROJECT_ROOT = %s' %(PROJECT_ROOT)

MEDIA_ROOT = os.path.join(PROJECT_ROOT, 'media')
print 'MEDIA_ROOT = %s' %(MEDIA_ROOT)



